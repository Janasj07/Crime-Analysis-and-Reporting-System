package com.java.CARS.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.java.CARS.model.Cases;

public class CasesTest {

    @Test
    public void testToString() {
        Cases cases = new Cases(1, "Robbery at Bank", 101);
        String result = "Cases{caseId=1, caseDescription='Robbery at Bank', incidentsId=101}";
        assertEquals(result, cases.toString());
    }

    @Test
    public void testGettersAndSetters() {
        Cases cases = new Cases();
        cases.setCaseId(2);
        cases.setCaseDescription("Burglary at Night");
        cases.setIncidentsid(102);

        assertEquals(2, cases.getCaseId());
        assertEquals("Burglary at Night", cases.getCaseDescription());
        assertEquals(102, cases.getIncidentsid());
    }
}
