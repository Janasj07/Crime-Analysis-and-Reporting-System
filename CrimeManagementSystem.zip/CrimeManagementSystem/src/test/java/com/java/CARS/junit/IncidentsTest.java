package com.java.CARS.junit;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Date;
import com.java.CARS.model.Incidents;

public class IncidentsTest {

    @Test
    public void testToString() {
        Date date = new Date();
        Incidents incident = new Incidents(1, "Robbery", date, "Main Street", "Armed robbery at store", "Open", 10, 20);

        String expected = "Incidents{" +
                "incidentID=1" +
                ", incidentType='Robbery'" +
                ", incidentDate=" + date +
                ", location='Main Street'" +
                ", description='Armed robbery at store'" +
                ", status='Open'" +
                ", victimID=10" +
                ", suspectID=20" +
                '}';

        assertEquals(expected, incident.toString());
    }

    @Test
    public void testGettersAndSetters() {
        Incidents incident = new Incidents();
        Date date = new Date();

        incident.setIncidentID(2);
        incident.setIncidentType("Homicide");
        incident.setIncidentDate(date);
        incident.setLocation("Downtown");
        incident.setDescription("Fatal shooting");
        incident.setStatus("Closed");
        incident.setVictimID(30);
        incident.setSuspectID(40);

        assertEquals(2, incident.getIncidentID());
        assertEquals("Homicide", incident.getIncidentType());
        assertEquals(date, incident.getIncidentDate());
        assertEquals("Downtown", incident.getLocation());
        assertEquals("Fatal shooting", incident.getDescription());
        assertEquals("Closed", incident.getStatus());
        assertEquals(30, incident.getVictimID());
        assertEquals(40, incident.getSuspectID());
    }
}
