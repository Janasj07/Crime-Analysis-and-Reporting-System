package com.java.CARS.junit;

import static org.junit.Assert.*;

import org.junit.Test;
import com.java.CARS.model.Evidence;

public class EvidenceTest {

    @Test
    public void testToString() {
        Evidence evidence = new Evidence();
        evidence.setEvidenceID(1);
        evidence.setDescription("Blood-stained knife");
        evidence.setLocationFound("Kitchen");
        evidence.setIncidentID(101);

        String expected = "Evidence{" +
                "evidenceID=1" +
                ", description='Blood-stained knife'" +
                ", locationFound='Kitchen'" +
                ", incidentID=101" +
                '}';

        assertEquals(expected, evidence.toString());
    }

    @Test
    public void testGettersAndSetters() {
        Evidence evidence = new Evidence();
        evidence.setEvidenceID(2);
        evidence.setDescription("Fingerprint on window");
        evidence.setLocationFound("Living room");
        evidence.setIncidentID(202);

        assertEquals(2, evidence.getEvidenceID());
        assertEquals("Fingerprint on window", evidence.getDescription());
        assertEquals("Living room", evidence.getLocationFound());
        assertEquals(202, evidence.getIncidentID());
    }
}
