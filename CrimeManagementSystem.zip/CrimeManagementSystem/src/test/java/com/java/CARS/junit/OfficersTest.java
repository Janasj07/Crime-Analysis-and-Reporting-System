package com.java.CARS.junit;

import static org.junit.Assert.*;
import org.junit.Test;
import com.java.CARS.model.Officers;

public class OfficersTest {

    @Test
    public void testGettersAndSetters() {
        Officers officer = new Officers();

        officer.setOfficerID(1);
        officer.setFirstName("John");
        officer.setLastName("Doe");
        officer.setBadgeNumber("PD123");
        officer.setRank("Sergeant");
        officer.setContactInformation("123 Main St");
        officer.setAgencyID(10);

        assertEquals(1, officer.getOfficerID());
        assertEquals("John", officer.getFirstName());
        assertEquals("Doe", officer.getLastName());
        assertEquals("PD123", officer.getBadgeNumber());
        assertEquals("Sergeant", officer.getRank());
        assertEquals("123 Main St", officer.getContactInformation());
        assertEquals(10, officer.getAgencyID());
    }

    @Test
    public void testToString() {
        Officers officer = new Officers();

        officer.setOfficerID(2);
        officer.setFirstName("Alice");
        officer.setLastName("Smith");
        officer.setBadgeNumber("PD456");
        officer.setRank("Lieutenant");
        officer.setContactInformation("456 Oak St");
        officer.setAgencyID(20);

        String expected = "Officers{" +
                "officerID=2" +
                ", firstName='Alice'" +
                ", lastName='Smith'" +
                ", badgeNumber='PD456'" +
                ", rank='Lieutenant'" +
                ", contactInformation='456 Oak St'" +
                ", agencyID=20" +
                '}';

        assertEquals(expected, officer.toString());
    }
}
