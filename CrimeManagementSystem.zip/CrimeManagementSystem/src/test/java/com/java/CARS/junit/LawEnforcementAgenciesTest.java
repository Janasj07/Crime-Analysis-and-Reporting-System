package com.java.CARS.junit;

import static org.junit.Assert.*;
import org.junit.Test;
import com.java.CARS.model.LawEnforcementAgencies;

public class LawEnforcementAgenciesTest {

    @Test
    public void testGettersAndSetters() {
        LawEnforcementAgencies agency = new LawEnforcementAgencies();

        agency.setAgencyID(1);
        agency.setAgencyName("City Police Department");
        agency.setJurisdiction("Urban");
        agency.setContactInformation("123 Main St, City");

        assertEquals(1, agency.getAgencyID());
        assertEquals("City Police Department", agency.getAgencyName());
        assertEquals("Urban", agency.getJurisdiction());
        assertEquals("123 Main St, City", agency.getContactInformation());
    }

    @Test
    public void testToString() {
        LawEnforcementAgencies agency = new LawEnforcementAgencies();

        agency.setAgencyID(2);
        agency.setAgencyName("County Sheriff Office");
        agency.setJurisdiction("Rural");
        agency.setContactInformation("456 County Rd");

        String expected = "LawEnforcementAgencies{" +
                "agencyID=2" +
                ", agencyName='County Sheriff Office'" +
                ", jurisdiction='Rural'" +
                ", contactInformation='456 County Rd'" +
                '}';

        assertEquals(expected, agency.toString());
    }
}
