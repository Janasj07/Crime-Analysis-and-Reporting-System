package com.java.CARS.junit;

import static org.junit.Assert.*;
import org.junit.Test;
import com.java.CARS.model.Reports;

import java.util.Date;

public class ReportsTest {

    @Test
    public void testGettersAndSetters() {
        Reports report = new Reports();
        Date date = new Date();

        report.setReportID(1);
        report.setIncidentID(1001);
        report.setReportingOfficer(101);
        report.setReportDate(date);
        report.setReportDetails("Suspect fled the scene.");
        report.setStatus("Open");

        assertEquals(1, report.getReportID());
        assertEquals(1001, report.getIncidentID());
        assertEquals(101, report.getReportingOfficer());
        assertEquals(date, report.getReportDate());
        assertEquals("Suspect fled the scene.", report.getReportDetails());
        assertEquals("Open", report.getStatus());
    }

    @Test
    public void testToString() {
        Reports report = new Reports();
        Date date = new Date();

        report.setReportID(2);
        report.setIncidentID(2002);
        report.setReportingOfficer(202);
        report.setReportDate(date);
        report.setReportDetails("Initial investigation completed.");
        report.setStatus("Submitted");

        String expected = "Reports{" +
                "reportID=2" +
                ", incidentID=2002" +
                ", reportingOfficer=202" +
                ", reportDate=" + date +
                ", reportDetails='Initial investigation completed.'" +
                ", status='Submitted'" +
                '}';

        assertEquals(expected, report.toString());
    }
}
