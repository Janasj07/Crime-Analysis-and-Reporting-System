package com.java.CARS.junit;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Date;
import com.java.CARS.model.Suspects;

public class SuspectsTest {

    @Test
    public void testGettersAndSetters() {
        Suspects suspect = new Suspects();
        Date dob = new Date();

        suspect.setSuspectID(1);
        suspect.setFirstName("Mark");
        suspect.setLastName("Johnson");
        suspect.setDateOfBirth(dob);
        suspect.setGender("Male");
        suspect.setContactInformation("123 Main St");

        assertEquals(1, suspect.getSuspectID());
        assertEquals("Mark", suspect.getFirstName());
        assertEquals("Johnson", suspect.getLastName());
        assertEquals(dob, suspect.getDateOfBirth());
        assertEquals("Male", suspect.getGender());
        assertEquals("123 Main St", suspect.getContactInformation());
    }

    @Test
    public void testToString() {
        Date dob = new Date();
        Suspects suspect = new Suspects(2, "Linda", "Smith", dob, "Female", "456 Oak Rd");

        String expected = "Suspects{" +
                "suspectID=2" +
                ", firstName='Linda'" +
                ", lastName='Smith'" +
                ", dateOfBirth='" + dob + '\'' +
                ", gender='Female'" +
                ", contactInformation='456 Oak Rd'" +
                '}';

        assertEquals(expected, suspect.toString());
    }
}
