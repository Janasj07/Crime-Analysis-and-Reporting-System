package com.java.CARS.junit;

import static org.junit.Assert.*;
import org.junit.Test;

import com.java.CARS.model.Victims;

import java.util.Date;

public class VictimsTest {

    @Test
    public void testGettersAndSetters() {
        Victims victim = new Victims();
        Date dob = new Date();

        victim.setVictimID(100);
        victim.setFirstName("Alice");
        victim.setLastName("Brown");
        victim.setDateOfBirth(dob);
        victim.setGender("Female");
        victim.setContactInformation("789 Maple Ave");

        assertEquals(100, victim.getVictimID());
        assertEquals("Alice", victim.getFirstName());
        assertEquals("Brown", victim.getLastName());
        assertEquals(dob, victim.getDateOfBirth());
        assertEquals("Female", victim.getGender());
        assertEquals("789 Maple Ave", victim.getContactInformation());
    }

    @Test
    public void testToString() {
        Date dob = new Date();
        Victims victim = new Victims(101, "John", "Doe", dob, "Male", "456 Pine St");

        String expected = "Victims{" +
                "victimID=101" +
                ", firstName='John'" +
                ", lastName='Doe'" +
                ", dateOfBirth='" + dob + '\'' +
                ", gender='Male'" +
                ", contactInformation='456 Pine St'" +
                '}';

        assertEquals(expected, victim.toString());
    }
}
