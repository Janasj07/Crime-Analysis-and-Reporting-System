package com.java.CARS.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.CARS.model.Incidents;
import com.java.CARS.util.ConnectionHelper;

public class IncidentDAOImpl implements IncidentsDao {

	@Override
	public Incidents getIncidentById(int incidentId) {
	    Incidents incident = null;
	    String query = "SELECT * FROM Incidents WHERE IncidentID = ?";
	    try (Connection conn = ConnectionHelper.getMyDbConnection();
	         PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setInt(1, incidentId);
	        ResultSet rs = ps.executeQuery();
	        if (rs.next()) {
	            incident = new Incidents();
	            incident.setIncidentID(rs.getInt("IncidentID"));
	            incident.setIncidentType(rs.getString("IncidentType"));
	            incident.setIncidentDate(rs.getDate("IncidentDate"));
	            incident.setLocation(rs.getString("Location"));
	            incident.setDescription(rs.getString("Descriptions"));
	            incident.setStatus(rs.getString("Statuss"));
	            incident.setVictimID(rs.getInt("VictimID"));
	            incident.setSuspectID(rs.getInt("SuspectID"));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return incident;
	}
}
