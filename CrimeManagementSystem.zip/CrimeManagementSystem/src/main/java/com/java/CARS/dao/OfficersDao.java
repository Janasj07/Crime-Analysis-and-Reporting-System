package com.java.CARS.dao;

import java.util.List;
import com.java.CARS.model.Officers;

public interface OfficersDao {
    List<Officers> getOfficersByIncidentId(int incidentId);
}
