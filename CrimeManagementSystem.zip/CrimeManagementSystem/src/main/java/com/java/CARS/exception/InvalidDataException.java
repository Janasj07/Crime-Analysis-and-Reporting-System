package com.java.CARS.exception;

public class InvalidDataException extends Exception {

	private static final long serialVersionUID = 1L;
	public InvalidDataException() {
		System.out.println("enter valid data");
	}
	public String toString(){
		return "given data not valid";
		
	}
}
