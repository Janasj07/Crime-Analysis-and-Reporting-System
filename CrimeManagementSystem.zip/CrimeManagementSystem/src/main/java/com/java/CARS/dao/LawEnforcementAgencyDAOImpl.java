package com.java.CARS.dao;

import java.sql.*;
import com.java.CARS.model.LawEnforcementAgencies;
import com.java.CARS.util.ConnectionHelper;

public class LawEnforcementAgencyDAOImpl implements LawEnforcementAgencyDao {

    @Override
    public LawEnforcementAgencies getAgencyById(int agencyId) {
        LawEnforcementAgencies agency = null;
        String query = "SELECT * FROM LawEnforcementAgencies WHERE AgencyID = ?";
        try (Connection conn = ConnectionHelper.getMyDbConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, agencyId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                agency = new LawEnforcementAgencies();
                agency.setAgencyID(rs.getInt("AgencyID"));
                agency.setAgencyName(rs.getString("AgencyName"));
                agency.setJurisdiction(rs.getString("Jurisdiction"));
                agency.setContactInformation(rs.getString("ContactInformation"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return agency;
    }
}
