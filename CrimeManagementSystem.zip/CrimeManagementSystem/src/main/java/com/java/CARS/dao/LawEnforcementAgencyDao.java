package com.java.CARS.dao;

import com.java.CARS.model.LawEnforcementAgencies;

public interface LawEnforcementAgencyDao {
    LawEnforcementAgencies getAgencyById(int agencyId);
}
