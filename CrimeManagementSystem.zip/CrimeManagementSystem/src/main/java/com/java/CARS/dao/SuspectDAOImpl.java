package com.java.CARS.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.CARS.model.Suspects;
import com.java.CARS.util.ConnectionHelper;

public class SuspectDAOImpl implements SuspectDao {

    @Override
    public Suspects getSuspectById(int suspectId) {
        Suspects s = null;
        String query = "SELECT * FROM Suspects WHERE SuspectID = ?";
        try (Connection conn = ConnectionHelper.getMyDbConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, suspectId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                s = new Suspects();
                s.setSuspectID(rs.getInt("SuspectID"));
                s.setFirstName(rs.getString("FirstName"));
                s.setLastName(rs.getString("LastName"));
                s.setDateOfBirth(rs.getDate("DateOfBirth"));
                s.setGender(rs.getString("Gender"));
                s.setContactInformation(rs.getString("ContactInformation"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return s;
    }
}
