package com.java.CARS.methodDao;

import com.java.CARS.exception.IncidentNumberNotFoundException;
import com.java.CARS.exception.InvalidDataException;

public interface IncidentsInterface {

	void createIncident() throws InvalidDataException;

	void updateIncidentStatus() throws IncidentNumberNotFoundException;

	void getIncidentsInDateRange();

	void searchIncidentsByType();

	void getAllIncidents();

}
