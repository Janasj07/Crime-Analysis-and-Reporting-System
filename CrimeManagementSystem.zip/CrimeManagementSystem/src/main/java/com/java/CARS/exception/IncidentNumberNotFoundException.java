package com.java.CARS.exception;

public class IncidentNumberNotFoundException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public String toString(){
		return "Incident Number Not Found in Db";
		
	}
}
