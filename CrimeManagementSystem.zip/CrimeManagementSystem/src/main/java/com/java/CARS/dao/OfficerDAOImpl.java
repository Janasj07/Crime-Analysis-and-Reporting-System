package com.java.CARS.dao;

import java.sql.*;
import java.util.*;

import com.java.CARS.model.Officers;
import com.java.CARS.util.ConnectionHelper;

public class OfficerDAOImpl implements OfficersDao {

    @Override
    public List<Officers> getOfficersByIncidentId(int incidentId) {
        List<Officers> list = new ArrayList<>();
        String query = "SELECT * FROM Officers WHERE IncidentID = ?";

        try (Connection conn = ConnectionHelper.getMyDbConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, incidentId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Officers o = new Officers();
                o.setOfficerID(rs.getInt("OfficerID"));
                o.setFirstName(rs.getString("FirstName"));
                o.setLastName(rs.getString("LastName"));
                o.setBadgeNumber(rs.getString("BadgeNumber"));
                o.setRank(rs.getString("Ranks"));
                o.setContactInformation(rs.getString("ContactInformation"));
                o.setAgencyID(rs.getInt("AgencyID"));
                list.add(o);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
}
