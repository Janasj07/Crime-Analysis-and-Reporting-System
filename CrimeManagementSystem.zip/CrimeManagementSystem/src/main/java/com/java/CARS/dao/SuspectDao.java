package com.java.CARS.dao;

import com.java.CARS.model.Suspects;

public interface SuspectDao {
    Suspects getSuspectById(int suspectId);
}
