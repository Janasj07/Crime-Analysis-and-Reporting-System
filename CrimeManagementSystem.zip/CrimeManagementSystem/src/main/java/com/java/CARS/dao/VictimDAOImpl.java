package com.java.CARS.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.CARS.model.Victims;
import com.java.CARS.util.ConnectionHelper;

public class VictimDAOImpl implements VictimDao {

    @Override
    public Victims getVictimById(int victimId) {
        Victims v = null;
        String query = "SELECT * FROM Victims WHERE VictimID = ?";
        try (Connection conn = ConnectionHelper.getMyDbConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, victimId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                v = new Victims();
                v.setVictimID(rs.getInt("VictimID"));
                v.setFirstName(rs.getString("FirstName"));
                v.setLastName(rs.getString("LastName"));
                v.setDateOfBirth(rs.getDate("DateOfBirth"));
                v.setGender(rs.getString("Gender"));
                v.setContactInformation(rs.getString("ContactInformation"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return v;
    }
}
