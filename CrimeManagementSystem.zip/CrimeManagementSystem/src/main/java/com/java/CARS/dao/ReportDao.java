package com.java.CARS.dao;

import java.util.List;
import com.java.CARS.model.Reports;

public interface ReportDao {
    List<Reports> getReportsByIncidentId(int incidentId);
}
