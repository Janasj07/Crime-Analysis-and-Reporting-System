package com.java.CARS.main;

import java.util.List;
import java.util.Scanner;

import com.java.CARS.dao.*;
import com.java.CARS.model.*;
import com.java.CARS.exception.IncidentNumberNotFoundException;
import com.java.CARS.exception.InvalidDataException;
import com.java.CARS.methodDao.CasesImpl;
import com.java.CARS.methodDao.CasesInterface;
import com.java.CARS.methodDao.IncidentsImpl;
import com.java.CARS.methodDao.IncidentsInterface;

public class MainClass {

    public static void main(String[] args) {
        System.out.println("Welcome to Crime Analysis and Reporting System");

        IncidentsInterface incidentsInterface = new IncidentsImpl();
        CasesInterface casesInterface = new CasesImpl();

        // DAO objects
        VictimDao victimDao = new VictimDAOImpl();
        SuspectDao suspectDao = new SuspectDAOImpl();
        OfficersDao officerDao = new OfficerDAOImpl();
        EvidenceDao evidenceDao = new EvidenceDAOImpl();
        ReportDao reportDao = new ReportDAOImpl();
        IncidentsDao incidentDao = new IncidentDAOImpl();
        LawEnforcementAgencyDao agencyDao = new LawEnforcementAgencyDAOImpl();

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nEnter your choice");
            System.out.println("1. Create Incident");
            System.out.println("2. Update the status of an incident");
            System.out.println("3. Get a list of incidents within a date range");
            System.out.println("4. Search for incidents based on various criteria");
            System.out.println("5. Get all incidents");
            System.out.println("6. Create a new case and associate it with incidents");
            System.out.println("7. Get details of a specific case");
            System.out.println("8. Update case details");
            System.out.println("9. Get a list of all cases");
            System.out.println("10. Exit");

            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    try {
                        incidentsInterface.createIncident();
                    } catch (InvalidDataException e) {
                        e.printStackTrace();
                    }
                    break;

                case 2:
                    try {
                        incidentsInterface.updateIncidentStatus();
                    } catch (IncidentNumberNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;

                case 3:
                    incidentsInterface.getIncidentsInDateRange();
                    break;

                case 4:
                    incidentsInterface.searchIncidentsByType();
                    break;

                case 5:
                    incidentsInterface.getAllIncidents();
                    break;

                case 6:
                    casesInterface.createCase();
                    break;

                case 7:
                    System.out.print("Enter Incident ID: ");
                    int incidentId = sc.nextInt();

                    Incidents incident = incidentDao.getIncidentById(incidentId);
                    if (incident != null) {
                        System.out.println("\n===== INCIDENT DETAILS =====");
                        System.out.println(incident);

                        System.out.println("\n===== VICTIM DETAILS =====");
                        Victims victim = victimDao.getVictimById(incident.getVictimID());
                        if (victim != null) {
                            System.out.println(victim);
                        } else {
                            System.out.println("No victim found.");
                        }

                        System.out.println("\n===== SUSPECT DETAILS =====");
                        Suspects suspect = suspectDao.getSuspectById(incident.getSuspectID());
                        if (suspect != null) {
                            System.out.println(suspect);
                        } else {
                            System.out.println("No suspect found.");
                        }

                        System.out.println("\n===== OFFICERS & AGENCIES =====");
                        List<Officers> officers = officerDao.getOfficersByIncidentId(incidentId);
                        if (officers.isEmpty()) {
                            System.out.println("No officers found.");
                        } else {
                            for (Officers o : officers) {
                                System.out.println(o);
                                LawEnforcementAgencies agency = agencyDao.getAgencyById(o.getAgencyID());
                                if (agency != null) {
                                    System.out.println(" → Agency: " + agency.getAgencyName() +
                                            ", Jurisdiction: " + agency.getJurisdiction() +
                                            ", Contact: " + agency.getContactInformation());
                                } else {
                                    System.out.println(" → Agency details not found.");
                                }
                            }
                        }

                        System.out.println("\n===== EVIDENCE =====");
                        List<Evidence> evidenceList = evidenceDao.getEvidenceByIncidentId(incidentId);
                        if (evidenceList.isEmpty()) {
                            System.out.println("No evidence found.");
                        } else {
                            evidenceList.forEach(System.out::println);
                        }

                        System.out.println("\n===== REPORTS =====");
                        List<Reports> reports = reportDao.getReportsByIncidentId(incidentId);
                        if (reports.isEmpty()) {
                            System.out.println("No reports found.");
                        } else {
                            reports.forEach(System.out::println);
                        }

                    } else {
                        System.out.println("Incident not found with ID: " + incidentId);
                    }
                    break;

                case 8:
                    casesInterface.updateCaseDetails();
                    break;

                case 9:
                    casesInterface.getAllCases();
                    break;

                case 10:
                    System.out.println("Thank you.....");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Choose a valid option (1-10).");
                    break;
            }
        }
    }
}
