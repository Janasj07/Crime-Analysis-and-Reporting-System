package com.java.CARS.dao;

import java.util.List;
import com.java.CARS.model.Evidence;

public interface EvidenceDao {
    List<Evidence> getEvidenceByIncidentId(int incidentId);
}
