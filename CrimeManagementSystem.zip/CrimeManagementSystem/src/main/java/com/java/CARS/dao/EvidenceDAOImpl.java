package com.java.CARS.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.CARS.model.Evidence;
import com.java.CARS.util.ConnectionHelper;

public class EvidenceDAOImpl implements EvidenceDao {

    @Override
    public List<Evidence> getEvidenceByIncidentId(int incidentId) {
        List<Evidence> list = new ArrayList<>();
        String query = "SELECT * FROM Evidence WHERE IncidentID = ?";

        try (Connection conn = ConnectionHelper.getMyDbConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, incidentId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Evidence e = new Evidence();
                e.setEvidenceID(rs.getInt("EvidenceID"));
                e.setDescription(rs.getString("Descriptions")); // matches your schema
                e.setLocationFound(rs.getString("LocationFound"));
                e.setIncidentID(rs.getInt("IncidentID"));
                list.add(e);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
}
