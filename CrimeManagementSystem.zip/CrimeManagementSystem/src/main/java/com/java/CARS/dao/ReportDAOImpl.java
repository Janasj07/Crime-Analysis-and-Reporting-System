package com.java.CARS.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.CARS.model.Reports;
import com.java.CARS.util.ConnectionHelper;

public class ReportDAOImpl implements ReportDao {

    @Override
    public List<Reports> getReportsByIncidentId(int incidentId) {
        List<Reports> list = new ArrayList<>();
        String query = "SELECT * FROM Reports WHERE IncidentID = ?";
        try (Connection conn = ConnectionHelper.getMyDbConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, incidentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reports r = new Reports();
                r.setReportID(rs.getInt("ReportID"));
                r.setIncidentID(rs.getInt("IncidentID"));
                r.setReportingOfficer(rs.getInt("ReportingOfficer"));
                r.setReportDate(rs.getDate("ReportDate"));
                r.setReportDetails(rs.getString("ReportDetails"));
                r.setStatus(rs.getString("Statuss"));
                list.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
