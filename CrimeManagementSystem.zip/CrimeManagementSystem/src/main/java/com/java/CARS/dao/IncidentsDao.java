package com.java.CARS.dao;

import com.java.CARS.model.Incidents;

public interface IncidentsDao {
    Incidents getIncidentById(int incidentId);
}
