package com.java.CARS.dao;

import com.java.CARS.model.Victims;

public interface VictimDao {
    Victims getVictimById(int victimId);
}
