package com.java.CARS.methodDao;

public interface CasesInterface {

	void createCase();

	void getCaseDetails();

	void updateCaseDetails();

	void getAllCases();

}
